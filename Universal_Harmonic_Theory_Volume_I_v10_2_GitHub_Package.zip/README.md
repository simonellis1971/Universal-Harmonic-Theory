# Universal Harmonic Theory - Volume I

Author: Simon Ellis  
Edition: Concise Definitive Editorial Edition - Working Publication Draft v10.2  
Date: 6 July 2026

This repository preserves **Universal Harmonic Theory, Volume I** as a public research manuscript for discussion, critique, mathematical refinement and future empirical testing.

## Main files

- `binaries/Universal_Harmonic_Theory_Volume_I_Concise_Draft_v10_2_GitHub.docx` - editable Word manuscript binary
- `binaries/Universal_Harmonic_Theory_Volume_I_Concise_Draft_v10_2_GitHub.pdf` - publication PDF binary
- `manuscript.md` - GitHub-readable text version
- `CITATION.cff` - citation metadata for GitHub and Zenodo
- `LICENSE` - public research sharing licence placeholder

## Scientific status

This work is a theoretical and speculative framework. It is not presented as experimentally established physics. Equations are internal definitions or hypotheses unless independently derived, peer reviewed and empirically validated.

## Recommended archive route

1. Keep this repository public on GitHub.
2. Create a GitHub release named `v10.2`.
3. Link the repository to Zenodo.
4. Archive the release to obtain a DOI.
5. Add the DOI badge and DOI link to this README.
