# Universal Harmonic Theory - Volume I (LaTeX)

This is a modular LaTeX migration of the source files available at the time of assembly.

## Build

```bash
pdflatex main.tex
pdflatex main.tex
```

The output is `main.pdf`.

## Important

- Files named `chapter##_placeholder.tex` indicate missing original chapter sources.
- Replace each placeholder with the verified source before calling the edition complete.
- Keep each chapter modular. This avoids the instability of one extremely large Word file.
- Original supporting MusicXML is preserved in `resources/`.

## Recommended workflow

1. Add or replace chapter `.tex` files.
2. Compile twice to refresh the table of contents.
3. Commit each change to GitHub.
4. Archive release PDFs and source ZIPs in Zenodo.
